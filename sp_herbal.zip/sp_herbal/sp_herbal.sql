-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 17, 2020 at 12:39 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.3.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sp_herbal`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `datauser`
--

CREATE TABLE `datauser` (
  `id` int(11) NOT NULL,
  `Nama Lengkap` varchar(30) NOT NULL,
  `No HP` int(15) NOT NULL,
  `Jenis Kelamin` varchar(10) NOT NULL,
  `Alamat` varchar(100) NOT NULL,
  `Tanggal Konsultasi` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `datauser`
--

INSERT INTO `datauser` (`id`, `Nama Lengkap`, `No HP`, `Jenis Kelamin`, `Alamat`, `Tanggal Konsultasi`) VALUES
(1, 'abrar', 2147483647, 'laki-laki', 'PAM', '2020-11-10'),
(35, 'abrar H', 2147483647, 'laki-laki', 'pam 3', '2020-11-11'),
(36, 'asda', 2147483647, 'laki-laki', 'fasfaf', '2020-11-11'),
(37, 'abtat', 2147483647, 'laki-laki', 'axo', '2020-11-12'),
(38, 'abrar', 2147483647, 'laki-laki', 'pam', '2020-11-12');

-- --------------------------------------------------------

--
-- Table structure for table `gejala`
--

CREATE TABLE `gejala` (
  `id` int(11) NOT NULL,
  `kode` varchar(5) NOT NULL,
  `nama gejala` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gejala`
--

INSERT INTO `gejala` (`id`, `kode`, `nama gejala`) VALUES
(1, 'G01', 'Mual dan Muntah'),
(2, 'G02', 'Nafsu Makan Berkurang'),
(3, 'G03', 'Perut Sakit'),
(4, 'G04', 'Perut Kembung'),
(5, 'G05', 'Nyeri Ulu Hati'),
(6, 'G06', 'Panas di Dada'),
(7, 'G07', 'Nyeri Dada'),
(8, 'G08', 'Sendawa'),
(9, 'G09', 'Cegukan'),
(10, 'G10', 'Suara Serak'),
(11, 'G11', 'Disfagia (Susah Menelan)'),
(12, 'G12', 'Odinofagia (Nyeri Saat Menelan)'),
(13, 'G13', 'Muntah Darah'),
(14, 'G14', 'Kotoran Hitam/Berdarah'),
(15, 'G15', 'Berat Badan Turun'),
(16, 'G16', 'Lambung Terasa Panas'),
(17, 'G17', 'Lemah Letih Lesu'),
(18, 'G18', 'Sesak Nafas'),
(19, 'G19', 'Muka Pucat'),
(20, 'G20', 'Mudah Kenyang'),
(21, 'G21', 'Keluar Cairan dari Lambung'),
(22, 'G22', 'Sakit Pada Tukak Lambung');

-- --------------------------------------------------------

--
-- Table structure for table `penyakit`
--

CREATE TABLE `penyakit` (
  `id` int(11) NOT NULL,
  `kode penyakit` varchar(5) NOT NULL,
  `penyakit` varchar(50) NOT NULL,
  `info` longtext NOT NULL,
  `solusi` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `penyakit`
--

INSERT INTO `penyakit` (`id`, `kode penyakit`, `penyakit`, `info`, `solusi`) VALUES
(1, 'P01', 'Maag', '', ''),
(2, 'P02', 'Dispepsia', '', ''),
(3, 'P03', 'GERD', '', ''),
(4, 'P04', 'Kanker Lambung', '', ''),
(5, 'P05', 'Gastroparesis', '', ''),
(6, 'P06', 'Tukak Lambung', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tb_rule`
--

CREATE TABLE `tb_rule` (
  `id` int(11) NOT NULL,
  `G01` int(11) NOT NULL,
  `G02` int(11) NOT NULL,
  `G03` int(11) NOT NULL,
  `G04` int(11) NOT NULL,
  `G05` int(11) NOT NULL,
  `G06` int(11) NOT NULL,
  `G07` int(11) NOT NULL,
  `G08` int(11) NOT NULL,
  `G09` int(11) NOT NULL,
  `G10` int(11) NOT NULL,
  `G11` int(11) NOT NULL,
  `G12` int(11) NOT NULL,
  `G13` int(11) NOT NULL,
  `G14` int(11) NOT NULL,
  `G15` int(11) NOT NULL,
  `G16` int(11) NOT NULL,
  `G17` int(11) NOT NULL,
  `G18` int(11) NOT NULL,
  `G19` int(11) NOT NULL,
  `G20` int(11) NOT NULL,
  `G21` int(11) NOT NULL,
  `G22` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_rule`
--

INSERT INTO `tb_rule` (`id`, `G01`, `G02`, `G03`, `G04`, `G05`, `G06`, `G07`, `G08`, `G09`, `G10`, `G11`, `G12`, `G13`, `G14`, `G15`, `G16`, `G17`, `G18`, `G19`, `G20`, `G21`, `G22`) VALUES
(1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0),
(2, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0),
(3, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(4, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0),
(5, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0),
(6, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `datauser`
--
ALTER TABLE `datauser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gejala`
--
ALTER TABLE `gejala`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `penyakit`
--
ALTER TABLE `penyakit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_rule`
--
ALTER TABLE `tb_rule`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `datauser`
--
ALTER TABLE `datauser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `gejala`
--
ALTER TABLE `gejala`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `penyakit`
--
ALTER TABLE `penyakit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tb_rule`
--
ALTER TABLE `tb_rule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
